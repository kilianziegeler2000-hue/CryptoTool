CryptoTool – überprüfbare Python-Version
========================================

Voraussetzungen:
- Python 3.11 oder neuer

Installation und Start unter Windows:
1. ZIP-Datei vollständig entpacken.
2. Im entpackten Ordner PowerShell öffnen.
3. Abhängigkeiten installieren:
   python -m pip install -r requirements.txt
4. App starten:
   python CryptoTool.py

Der vollständige Quellcode ist in CryptoTool.py lesbar. Alle Dateioperationen
finden lokal statt. Private Schlüssel und Passwörter sicher aufbewahren.
