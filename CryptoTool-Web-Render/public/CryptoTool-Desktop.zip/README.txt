CryptoTool Modern GUI

INSTALLATION
------------
Öffne PowerShell im Programmordner und führe aus:

python -m pip install -r requirements.txt

START
-----
python crypto_modern.py

FUNKTIONEN
----------
- Moderne Dark-Mode-Oberfläche
- Datei per Drag & Drop auswählen
- Datei über Dialog auswählen
- RSA-Schlüsselpaar erstellen
- Dateien mit AES-256-EAX verschlüsseln
- AES-Schlüssel mit RSA-OAEP schützen
- Manipulierte Dateien beim Entschlüsseln erkennen
- Passwortgeschützte private RSA-Schlüssel erstellen
- Lange Aktionen mit Fortschrittsanzeige im Hintergrund ausführen
- Optionale, per SHA-256 geprüfte Sicherheitskopien erstellen
- SHA-256-Prüfsummen nach Ver- und Entschlüsselung anzeigen
- Prüfen, ob pub.key und priv.key zusammengehören
- Diagnoseergebnisse direkt in einem eigenen Fenster anzeigen
- Dateien und komplette Ordner auf typische Ransomware-Hinweise prüfen
- Lokales Aktivitätsprotokoll ohne Schlüssel oder Dateiinhalte führen

WICHTIG
-------
- priv.key niemals weitergeben.
- priv.key nicht löschen.
- Alte verschlüsselte Dateien benötigen den dazugehörigen alten privaten Schlüssel.
- Das Programm überschreibt Dateien nur nach Rückfrage.
- Das Passwort eines neuen priv.key kann nicht wiederhergestellt werden.
- Sicherheitskopien möglichst auf einem externen, danach getrennten Laufwerk speichern.
- Keine Ransomware-Prüfung kann eine Infektion mit absoluter Sicherheit ausschließen.
